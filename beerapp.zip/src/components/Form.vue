<template>
  <v-container>
    <v-row justify="space-around">
      <v-form ref="form" v-model="valid" class="form">
        <v-col class="mb-4">
          <v-text-field v-model="name" :counter="16" :rules="nameRules" label="Name" required></v-text-field>
        </v-col>
        <div class="my-2" required id="age">
          <v-btn small color :disabled="!valid" class="answer" @click="getAnswer">Login</v-btn>
          <h2>{{answer}}</h2>
        </div>
      </v-form>
    </v-row>
  </v-container>
</template>

<style lang="scss">
.my-2 {
  margin: 20px;
}

.active {
  color: lightgreen;
}
</style>


<script>
export default {
  data: () => ({
    valid: true,
    answers: "Are you over 18?",
    name: "",
    nameRules: [
      v => !!v || "Name is required",
      v => (v && v.length <= 16) || "Name must be less than 16characters"
    ]
  }),

  methods: {
    getAnswer: function() {
      let self = this;

      // eslint-disable-next-line no-undef
      // eslint-disable-next-line no-undef
      axios
        .get("https://yesno.wtf/api")
        .then(function(res) {
          if (res.data.answer === "yes") {
            console.log(res.data.answer);
            // eslint-disable-next-line no-undef
            self.answers = res.data.answer && "yes";
            return;
          } else {
            console.log(res.data.answer);
            self.answers = res.data.answer && "no";
          }
        })
        .catch(function(err) {
          this.answer = "Error: " + err;
        });
    },
    validate() {
      this.$refs.form.validate();
    }
  }
};
</script>
