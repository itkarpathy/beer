<template>
  <div class="home">
    <Form />
  </div>
</template>

<script>
// @ is an alias to /src
import Form from "@/components/Form";

export default {
  name: "Home",
  components: {
    Form
  }
};
</script>
