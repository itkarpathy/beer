<template>
  <v-app>
    <v-app-bar app color="black" dark>
      <div class="d-flex align-center">
        <v-img
          alt="Grape Logo"
          src="./assets/grape_logo.svg"
          class="shrink mr-2"
          transition="scale-transition"
          width="100"
        />
      </div>

      <v-spacer style="color: #83eb34; font-weight:bold">Beer finder</v-spacer>
    </v-app-bar>

    <v-content>
      <Form />
    </v-content>
  </v-app>
</template>

<script>
import Form from "./components/Form";

export default {
  name: "App",

  components: {
    Form
  },

  data: () => ({
    //
  })
};
</script>
